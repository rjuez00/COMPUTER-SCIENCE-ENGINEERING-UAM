ant limpiar-todo

ant compilar-servidor
ant empaquetar-servidor

ant compilar-cliente
ant empaquetar-cliente

ant empaquetar-aplicacion
ant redesplegar


