DROP TABLE pago;

DROP TABLE tarjeta;